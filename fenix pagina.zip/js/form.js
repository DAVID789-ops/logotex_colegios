document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault(); // Evita el envío del formulario

        // Limpia los campos del formulario
        document.getElementById('contact-form').reset();

        // Muestra el pop-up de información enviada
        alert('Información enviada');
    });
});